using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;
using System.Web.Configuration;

public partial class ListBesucherForm : BesanPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
        lblFooterDatum.Text = Global.GetDatum();

		if (!this.IsPostBack)
		{
			if (Session["MitarbeiterID"] != null)
			{
				Mitarbeiter m = Mitarbeiter.Get((int)Session["MitarbeiterID"]);
				cmbNachname.Items.Add(new ListItem(m.Nachname, m.MitarbeiterID.ToString()));
				besan2DataSet.GetAbholerTableFromIDDataTable abholerTable = Database.DataAccess.GetAbholerTableFromID(m.MitarbeiterID);
				foreach (DataRow row in abholerTable.Rows)
				{
					cmbNachname.Items.Add(new ListItem((string)row["Name"], row["VertreterID"].ToString()));
				}
				cmbNachname.SelectedValue = m.MitarbeiterID.ToString();
				this.BindBesuchter(m);
			}
			else
			{
				Response.Redirect("LoginForm.aspx");
			}
		}
		else
		{
			bool confirmDelete = ViewState["ConfirmDelete"] as bool? ?? false;
			if (confirmDelete)
			{
				if (Boolean.Parse(this.confirmDelete.Value))
				{
					int mitarbeiterID = (int)Session["MitarbeiterID"];
					Database.DataAccess.DeleteBesuch((int)besucherTable.DeletedValue);
					besucherTable.DataSource = Database.DataAccess.GetBesucherTableFromID(mitarbeiterID);
					Session["ConfirmDelete"] = false;
				}
			}
		}

		leftNavLink1.ServerClick += new EventHandler(leftNavLink1_ServerClick);
	}

	private void leftNavLink1_ServerClick(object sender, EventArgs e)
	{
		Session["BesuchFormMode"] = BesuchFormMode.Create;
		Response.Redirect("NewBesuchForm.aspx");
	}

	protected void besucherTable_SelectedRowChanged(object sender, BesucherVerwaltung.Controls.RowChangedEventArgs e)
	{
		bool canDelete = besucherTable.CanDeleteValue;
		Session["BesuchID"] = (int)besucherTable.SelectedValue;
		Session["BesuchFormMode"] = canDelete ? BesuchFormMode.Edit : BesuchFormMode.View;
		Response.Redirect("NewBesuchForm.aspx");		
	}

	protected void besucherTable_RowDeleted(object sender, BesucherVerwaltung.Controls.RowChangedEventArgs e)
	{
		this.ClientScript.RegisterStartupScript(typeof(ListBesucherForm), "ConfirmDelete", "ConfirmDelete('" + confirmDelete.ClientID + (string)GetGlobalResourceObject("Language","msg11"), true);
		ViewState["ConfirmDelete"] = true;
	}

    protected void besucherTable_RowCopy(object sender, BesucherVerwaltung.Controls.RowChangedEventArgs e)
    {
        bool canCopy = besucherTable.CanCopyRows;
        Session["BesuchID"] = (int)besucherTable.CopyValue;
        Session["BesuchFormMode"] = BesuchFormMode.Copy;
        Response.Redirect("NewBesuchForm.aspx");
    }

    protected void cmbNachname_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.BindBesuchter(Mitarbeiter.Get(Convert.ToInt32(cmbNachname.SelectedValue)));
	}

	private void BindBesuchter(Mitarbeiter besuchter)
	{
		txtVorname.Value = besuchter.Vorname;
		txtPersNr.Value = besuchter.PersNr;
		txtFKz.Value = besuchter.Fkz.ToString("0#");
        besan2DataSet.GetBesucherTableFromIDDataTable table = Database.DataAccess.GetBesucherTableFromID(besuchter.MitarbeiterID);
        table.BesuchernameColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String2");
        table.BesuchsdatumColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String4");
        table.FirmaColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String3");
        table.GruppeNameColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String1");
        besucherTable.DataSource = table;
       
            
        // besucherTable.Header = new string[] { (string)GetGlobalResourceObject("Language", "String1"), (string)GetGlobalResourceObject("Language", "String2"), (string)GetGlobalResourceObject("Language", "String3"), (string)GetGlobalResourceObject("Language", "String4"), (string)GetGlobalResourceObject("Language", "String5"), (string)GetGlobalResourceObject("Language", "String6") };
	}

    protected string GetDatum()
    {
        string datum = WebConfigurationManager.AppSettings.Get("datum");
        return datum;
    }
}