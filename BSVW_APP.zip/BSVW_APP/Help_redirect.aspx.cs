using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using System.Threading;

public partial class Help_redirect : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //HttpCookie cookie = Request.Cookies["besucheranmeldung"];
        HttpCookie cookie = Request.Cookies["besanlanguage"];
        switch (cookie["balang"])
        {
            case "de-AT":
                Response.Redirect("Hilfe.htm");
                break;
            case "en-US":
                Response.Redirect("Hilfe_en.htm");
                break;
            default:
                {
                Response.Redirect("Hilfe_en.htm");}
                break;
        }
    }
}
