vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Jul 2006 00:49:35 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|31 Jul 2006 00:49:35 -0000
vti_filesize:IR|418
