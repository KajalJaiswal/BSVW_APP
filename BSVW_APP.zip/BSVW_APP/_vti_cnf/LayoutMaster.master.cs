vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Jul 2006 10:12:31 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|30 Jul 2006 10:12:31 -0000
vti_filesize:IR|416
