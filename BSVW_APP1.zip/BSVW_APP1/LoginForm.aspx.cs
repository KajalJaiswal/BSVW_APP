using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;
using System.Globalization;
using System.Threading;
using System.Resources;


public partial class LoginForm : BesanPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblFooterDatum.Text = Global.GetDatum();

		if (!this.IsPostBack)
		{
            //Session["con"]= CurrentEnvironment.CurrentEnvironment.DbConnectionString;
            BesucherVerwaltung.Data.Settings.ConnectionString = CurrentEnvironment.CurrentEnvironment.DbConnectionString;
			DataAccess da = Database.DataAccess;
			cmbFkz.DataSource = da.GetFKz();
			cmbFkz.DataTextField = "Column1";
			cmbFkz.DataValueField = "FkzId";
			cmbFkz.DataBind();
            if (this.Request != null)
            {
				this.LoadCookie();
            }      
		}
    }

	protected void btnLogin_Click(object sender, EventArgs e)
	{
		this.SaveCookie();
		DataAccess da = Database.DataAccess;
		Mitarbeiter m = Mitarbeiter.Get(txtPersonalNumber.Value, Int32.Parse(cmbFkz.Value));
		if (m != null)
		{
			Session["MitarbeiterID"] = m.MitarbeiterID;
            Session["PersNr"] = m.PersNr;
            Session["BesuchFormMode"] = BesuchFormMode.Create;
			Response.Redirect("NewBesuchForm.aspx");
		}
		else
		{
            this.ClientScript.RegisterStartupScript(typeof(LoginForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg13"), true);
		}
	}

	protected void btnReset_Click(object sender, EventArgs e)
	{
		txtSurname.Value = String.Empty;
		txtName.Value = String.Empty;
		txtPersonalNumber.Value = String.Empty;
		cmbFkz.SelectedIndex = 0;
		this.SaveCookie();
	}

	private void SaveCookie()
	{
		HttpCookie cookie = Request.Cookies["besucheranmeldung"];

		if (cookie == null)
		{
			cookie = new HttpCookie("besucheranmeldung");
		}

		cookie["banname"] = txtSurname.Value;
		cookie["bavname"] = txtName.Value;
		cookie["bapernm"] = txtPersonalNumber.Value;
		cookie["bafirmenkz"] = cmbFkz.Value;
        cookie.Expires = DateTime.Now.AddDays(7);
		Response.AppendCookie(cookie);
	}

	private void LoadCookie()
	{
		HttpCookie cookie = Request.Cookies["besucheranmeldung"];
		if (cookie != null)
		{
			txtSurname.Value = cookie["banname"];
			txtName.Value = cookie["bavname"];
			txtPersonalNumber.Value = cookie["bapernm"];
			cmbFkz.Value = cookie["bafirmenkz"];
		}
	}
}