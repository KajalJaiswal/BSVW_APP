using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;
using System.Web.Services;

public partial class DeleteVertreterForm : BesanPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
        lblFooterDatum.Text = Global.GetDatum();

		if (!this.IsPostBack)
		{
			if (Session["MitarbeiterID"] != null)
			{
				Mitarbeiter m = Mitarbeiter.Get((int)Session["MitarbeiterID"]);
				cmbNachname.Items.Add(new ListItem(m.Nachname, m.MitarbeiterID.ToString()));
				txtVorname.Value = m.Vorname;
				txtPersNr.Value = m.PersNr;
				txtFKz.Value = m.Fkz.ToString("0#");
				this.BindVerterterTable(m.MitarbeiterID);
			}
			else
			{
				Response.Redirect("LoginForm.aspx");
			}
		}
		else
		{
			bool confirmDelete = ViewState["ConfirmDelete"] as bool? ?? false;
			if (confirmDelete)
			{
				if (Boolean.Parse(this.confirmDelete.Value))
				{
					int mitarbeiterID = (int)Session["MitarbeiterID"];
					Database.DataAccess.DeleteVertreter(mitarbeiterID, (int)vertreterTable.DeletedValue);
					this.BindVerterterTable(mitarbeiterID);
					Session["ConfirmDelete"] = false;
				}
			}
		}
	}

	protected void vertreterTable_RowDeleted(object sender, BesucherVerwaltung.Controls.RowChangedEventArgs e)
	{
		this.ClientScript.RegisterStartupScript(typeof(DeleteVertreterForm), "ConfirmDelete", "ConfirmDelete('" + confirmDelete.ClientID + (string)GetGlobalResourceObject("Language","msg12"), true);
		ViewState["ConfirmDelete"] = true;
	}

	private void BindVerterterTable(int mitarbeiterID)
	{
        besan2DataSet.GetVertreterTableFromIDDataTable table = Database.DataAccess.GetVertreterTableFromID(mitarbeiterID);
        table.BauColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String8");
        table.NameColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String7");
        table.RaumColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String9");
        table.PersNrColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String10");
        table.FkzColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String11");

        
        vertreterTable.DataSource = table;
	}
}