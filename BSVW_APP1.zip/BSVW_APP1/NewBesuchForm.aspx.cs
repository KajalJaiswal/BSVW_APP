using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;
using System.Globalization;
using System.Threading;

public partial class NewBesuchForm : BesanPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
        lblFooterDatum.Text = Global.GetDatum();

		BesuchFormMode formMode = Session["BesuchFormMode"] as BesuchFormMode? ?? BesuchFormMode.Create;

        if (!this.IsPostBack)
        {
            if (Session["MitarbeiterID"] != null)
            {
                Mitarbeiter m = Mitarbeiter.Get((int)Session["MitarbeiterID"]);

                for (int i = 0; i < 24; i++)
                {
                    string hour = i.ToString("0#");
                    cmbHourFrom.Items.Add(hour);
                    cmbHourTo.Items.Add(hour);
                }

                for (int i = 0; i < 60; i += 5)
                {
                    string minute = i.ToString("0#");
                    cmbMinuteFrom.Items.Add(minute);
                    cmbMinuteTo.Items.Add(minute);
                }

                lblDatum.Text = DateTime.Now.ToShortDateString();

                this.ChangeFormMode(formMode);

                Mitarbeiter besuchter = m;

                if (formMode != BesuchFormMode.Create)
                {
                    pageTitle.InnerText = (string)GetGlobalResourceObject("Language", "title53");
                    leftNavLink1.Attributes["class"] = "navLink2";
                    leftNavLink2.Attributes["class"] = "navLink2Selected";

                    int besuchID = (int)Session["BesuchID"];

                    BesucherVerwaltungClient.BesuchData besuchData = BesucherVerwaltungClient.BesuchData.FromDatabase(besuchID);

                    if (formMode == BesuchFormMode.Copy)
                    {
                        DateTime now = DateTime.Now;

                        cmbHourFrom.SelectedIndex = now.TimeOfDay.Hours + 1;
                        cmbMinuteFrom.SelectedIndex = 0;
                        cmbHourTo.SelectedIndex = now.TimeOfDay.Hours + 3;
                        cmbMinuteTo.SelectedIndex = 0;
                    }
                    else
                    {
                        DateTime geplanntEnde = besuchData.GeplanntEnde.Value;
                        dtpFrom.SelectedDate = besuchData.GeplanntBeginn;
                        cmbHourFrom.Value = besuchData.GeplanntBeginn.Hour.ToString("0#");
                        cmbMinuteFrom.Value = besuchData.GeplanntBeginn.Minute.ToString("0#");
                        dtpTo.SelectedDate = geplanntEnde;
                        cmbHourTo.Value = geplanntEnde.Hour.ToString("0#");
                        cmbMinuteTo.Value = geplanntEnde.Minute.ToString("0#");
                    }

                    txtGroup.Value = besuchData.GruppeID.HasValue ? besuchData.GruppeName : String.Empty;

                    besuchter = Mitarbeiter.Get(besuchData.MitarbeiterID);

                    for (int i = 0; i < besuchData.BesucherList.Count; i++)
                    {
                        BesucherVerwaltungClient.Besucher besucher = besuchData.BesucherList[i];
                        BesucherVerwaltungClient.BesuchPerson besuchPerson = besuchData.BesuchPersonList[i];

                        string besucherName = besucher.Nachname + (!String.IsNullOrEmpty(besucher.Vorname) ? " " + besucher.Vorname : String.Empty);
                        BesucherVerwaltung.Controls.BesucherTabPage tabPage = BesucherTabControl1.AddTabPage(besucherName);

                        tabPage.Anrede = besucher.Anrede;
                        tabPage.Titel = besucher.Titel;
                        tabPage.AusweisNr = besucher.AusweisNummer;
                        tabPage.Nachname = besucher.Nachname;
                        tabPage.Vorname = besucher.Vorname;
                        tabPage.Firma = besucher.Firma;
                        tabPage.Telefon = besucher.Telefon;
                        tabPage.VIP = besucher.Vip ?? false;
                        tabPage.Sicher = besucher.SicherheitsHinweis;

                        tabPage.Ort = besuchPerson.AbholerOrt;
                        tabPage.Autonummer = besuchPerson.AutoNummer;
                        tabPage.Parkplatz = besuchPerson.ParkPlatz.HasValue ? besuchPerson.ParkPlatz.Value : false;
                        tabPage.Bemerkungen = besuchPerson.Bemerkung;

                        tabPage.ReadOnly = formMode == BesuchFormMode.View;
                    }

                    lblGroupSize.Text = besuchData.BesucherList.Count.ToString();

                    if (formMode == BesuchFormMode.Edit)
                    {
                        Session["BesuchData"] = besuchData;
                        btnOkay.Text = (string)GetGlobalResourceObject("Language", "title54");
                    }
                    else if (formMode == BesuchFormMode.Copy)
                    {
                        btnOkay.Text = (string)GetGlobalResourceObject("Language", "But4");
                    }
                    else
                    {
                        btnOkay.Text = (string)GetGlobalResourceObject("Language", "title55");
                    }
                }
                else
                {
                    this.InitForm();
                }

                Session["BesuchterID"] = besuchter.MitarbeiterID;

                cmbStandort.DataSource = Database.DataAccess.GetStandort2();
                cmbStandort.DataTextField = "StandortName";
                cmbStandort.DataValueField = "StandortID";
                cmbStandort.DataBind();

                cmbNachname.Items.Add(new ListItem(m.Nachname + " " + m.Vorname, m.MitarbeiterID.ToString()));
                besan2DataSet.GetAbholerTableFromIDDataTable abholerTable = Database.DataAccess.GetAbholerTableFromID(m.MitarbeiterID);
                foreach (DataRow row in abholerTable.Rows)
                {
                    cmbNachname.Items.Add(new ListItem((string)row["Name"], row["VertreterID"].ToString()));
                }
                cmbNachname.SelectedValue = besuchter.MitarbeiterID.ToString();

                this.BindBesuchter(besuchter);

                //TODO: BindFruhereBesucher
                //this.BindFruhereBesucher(besuchter.MitarbeiterID);
                int besuchterID = Convert.ToInt32(cmbNachname.SelectedValue);
                this.BindFruhereBesucher(besuchterID);

                BesucherTabControl1.SelectedTabIndex = 0;
            }
            else
            {
                Response.Redirect("LoginForm.aspx");
            }
        }
        else
        {
            if (Request.Form["__EVENTTARGET"].ToString() == "SetBesucher")
            {
                int besucherID = Convert.ToInt32(Request.Form["__EVENTARGUMENT"].ToString());
                SetBesucher(besucherID);
            }
        }
		for (int i = 0; i < BesucherTabControl1.TabPages.Count; i++)
		{
			//BesucherTabControl1.TabPages[i].BindFruhereBesucher(fbTable);
			BesucherTabControl1.TabPages[i].Anlegen += new EventHandler(tabPage_Anlegen);
			BesucherTabControl1.TabPages[i].Entfernen += new EventHandler(tabPage_Entfernen);
            BesucherTabControl1.TabPages[i].Select += new EventHandler(tabPage_Select);
			//BesucherTabControl1.TabPages[i].BesucherChanged += new EventHandler(tabPage_BesucherChanged);			
		}

		if (BesucherTabControl1.TabPages.Count == 1)
		{
			BesucherTabControl1.TabPages[0].DeleteEnabled = false;
		}

		mainNavLink2.ServerClick += new EventHandler(mainNavLink2_ServerClick);
		mainBottomNavLink2.ServerClick += new EventHandler(mainNavLink2_ServerClick);
		leftNavLink1.ServerClick += new EventHandler(leftNavLink1_ServerClick);
		leftNavLink2.ServerClick += new EventHandler(leftNavLink2_ServerClick);
	}

    public void SetBesucher(int besucherID)
    {
        BesucherVerwaltung.Controls.BesucherTabPage tabPage = BesucherTabControl1.TabPages[BesucherTabControl1.SelectedTabIndex];
      //  int besucherID = Convert.ToInt32(cmbFruhereBesucher.SelectedValue);
        besan2DataSet.GetBesucherFromIDRow besucherRow = Database.DataAccess.GetBesucherFromID(besucherID);
      //  BesucherVerwaltungClient.Besucher besucher = BesucherVerwaltungClient.Besucher.FromDataRow(besucherRow);
        tabPage.Anrede = besucherRow.IsAnredeNull() ? String.Empty : besucherRow.Anrede;
        tabPage.Titel = besucherRow.IsTitelNull() ? String.Empty : besucherRow.Titel;
        tabPage.AusweisNr = besucherRow.IsAusweisNrNull() ? String.Empty : besucherRow.AusweisNr;
        tabPage.Nachname = besucherRow.Nachname;
        tabPage.Vorname = besucherRow.IsVornameNull() ? String.Empty : besucherRow.Vorname;
        tabPage.Firma = besucherRow.IsFirmaNull() ? String.Empty : besucherRow.Firma;
        tabPage.Telefon = besucherRow.IsTelefonNull() ? String.Empty : besucherRow.Telefon;
        tabPage.VIP = besucherRow.VIP;
        tabPage.Sicher = besucherRow.IsSicherheitshinweisNull()?String.Empty:besucherRow.Sicherheitshinweis;
 
    }

	protected void cmbFruhereBesucher_SelectedIndexChanged(object sender, EventArgs e)
	{
        //BesucherVerwaltung.Controls.BesucherTabPage tabPage = BesucherTabControl1.TabPages[BesucherTabControl1.SelectedTabIndex];
        //int besucherID = Convert.ToInt32(cmbFruhereBesucher.SelectedValue);
        //tabPage.BesucherID = besucherID;

        //if (besucherID > 0)
        //{
        //    besan2DataSet.GetBesucherFromIDRow besucherRow = Database.DataAccess.GetBesucherFromID(besucherID);
        //    BesucherVerwaltungClient.Besucher besucher = BesucherVerwaltungClient.Besucher.FromDataRow(besucherRow);
			
        //    tabPage.Anrede = besucher.Anrede;
        //    tabPage.Titel = besucher.Titel;
        //    tabPage.AusweisNr = besucher.AusweisNummer;
        //    tabPage.Nachname = besucher.Nachname;
        //    tabPage.Vorname = besucher.Vorname;
        //    tabPage.Firma = besucher.Firma;
        //    tabPage.Telefon = besucher.Telefon;
        //    tabPage.VIP = besucher.Vip ?? false;
        //    tabPage.Sicher = besucher.SicherheitsHinweis;
        //}
	}

	protected void cmbNachname_SelectedIndexChanged(object sender, EventArgs e)
	{
		Mitarbeiter m = Mitarbeiter.Get(Convert.ToInt32(cmbNachname.SelectedValue));
		this.BindBesuchter(m);
		this.BindFruhereBesucher(m.MitarbeiterID);
	}	

	private void tabPage_Anlegen(object sender, EventArgs e)
	{
		BesucherVerwaltung.Controls.BesucherTabPage previous = (BesucherVerwaltung.Controls.BesucherTabPage)sender;
		if (String.IsNullOrEmpty(previous.Nachname))
		{
            return;
		}

        BesucherVerwaltung.Controls.BesucherTabPage tabPage = BesucherTabControl1.AddTabPage((string)GetGlobalResourceObject("Language", "title56"));
		tabPage.DeleteEnabled = false;
		
		BesucherVerwaltungClient.BesuchData besuchData = (BesucherVerwaltungClient.BesuchData)Session["BesuchData"];
		if (tabPage.Index > besuchData.BesucherList.Count)
		{
			besuchData.BesucherList.Add(new BesucherVerwaltungClient.Besucher());
			besuchData.BesuchPersonList.Add(new BesucherVerwaltungClient.BesuchPerson());
			Session["BesuchData"] = besuchData;
		}
        

		//BesucherVerwaltung.Controls.BesucherTabPage previous = BesucherTabControl1.TabPages[tabPage.Index - 1];
		string besucherName = previous.Nachname + (!String.IsNullOrEmpty(previous.Vorname) ? " " + previous.Vorname : String.Empty);		
		previous.InsertEnabled = false;
		previous.DeleteEnabled = true;
		previous.Text = besucherName;
        lblGroupSize.Text = besuchData.BesucherList.Count.ToString();
	}

	private void tabPage_Entfernen(object sender, EventArgs e)
	{
		BesucherVerwaltung.Controls.BesucherTabPage tabPage = (BesucherVerwaltung.Controls.BesucherTabPage)sender;
		BesucherTabControl1.RemoveTabPage(tabPage.Index);

		BesucherVerwaltungClient.BesuchData besuchData = (BesucherVerwaltungClient.BesuchData)Session["BesuchData"];
		if (tabPage.Index < besuchData.BesucherList.Count)
		{
			besuchData.BesucherList.RemoveAt(tabPage.Index);
			besuchData.BesuchPersonList.RemoveAt(tabPage.Index);
		}

		BesucherVerwaltung.Controls.BesucherTabPage last = BesucherTabControl1.TabPages[BesucherTabControl1.TabPages.Count - 1];
		last.InsertEnabled = true;
		last.DeleteEnabled = last.Index > 0;
        lblGroupSize.Text = besuchData.BesucherList.Count.ToString();
	}

    void tabPage_Select(object sender, EventArgs e)
    {        
        BesucherVerwaltung.Controls.BesucherTabPage tabPage = (BesucherVerwaltung.Controls.BesucherTabPage)sender;
        Session["nachnamestring"] = tabPage.Nachname;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "OpenDialog", "OpenDialog('" + tabPage.Nachname + "')", true);
    }

	//private void tabPage_BesucherChanged(object sender, EventArgs e)
	//{
	//    BesucherVerwaltung.Controls.BesucherTabPage tabPage = (BesucherVerwaltung.Controls.BesucherTabPage)sender;

	//    int besucherID = tabPage.FruhereBesucher;
	//    if (besucherID > 0)
	//    {
	//        besan2DataSet.GetBesucherFromIDRow besucherRow = Database.DataAccess.GetBesucherFromID(besucherID);
	//        BesucherVerwaltungClient.Besucher besucher = BesucherVerwaltungClient.Besucher.FromDataRow(besucherRow);

	//        tabPage.Anrede = besucher.Anrede;
	//        tabPage.Titel = besucher.Titel;
	//        tabPage.AusweisNr = besucher.AusweisNummer;
	//        tabPage.Nachname = besucher.Nachname;
	//        tabPage.Vorname = besucher.Vorname;
	//        tabPage.Firma = besucher.Firma;
	//        tabPage.Telefon = besucher.Telefon;
	//        tabPage.VIP = besucher.Vip ?? false;
	//        tabPage.Sicher = besucher.SicherheitsHinweis;
	//    }
	//}

	private void mainNavLink2_ServerClick(object sender, EventArgs e)
	{
		Session["BesuchFormMode"] = BesuchFormMode.Create;
		Response.Redirect("NewBesuchForm.aspx");
	}
	
	private void leftNavLink1_ServerClick(object sender, EventArgs e)
	{
		Session["BesuchFormMode"] = BesuchFormMode.Create;
		Response.Redirect("NewBesuchForm.aspx");
	}

	private void leftNavLink2_ServerClick(object sender, EventArgs e)
	{
		Response.Redirect("ListBesucherForm.aspx");
	}

	protected void btnOkay_Click(object sender, EventArgs e)
	{
		BesuchFormMode formMode = (BesuchFormMode)Session["BesuchFormMode"];

		if (formMode == BesuchFormMode.View)
		{
			Response.Redirect("ListBesucherForm.aspx");
		}
		else
		{
			DateTime now = DateTime.Now;
			DateTime from = dtpFrom.SelectedDate;
			DateTime to = dtpTo.SelectedDate;
			TimeSpan timeFrom = new TimeSpan(Convert.ToInt32(cmbHourFrom.Value), Convert.ToInt32(cmbMinuteFrom.Value), 0);
			TimeSpan timeTo = new TimeSpan(Convert.ToInt32(cmbHourTo.Value), Convert.ToInt32(cmbMinuteTo.Value), 0);
			if (from.Date < now.Date)
			{
                this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg2") + ";", true);
                dtpFrom.Focus();
				return;
			}
			else if (from.Date == now.Date && timeFrom < now.TimeOfDay)
			{
                this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg3") + ";", true);
                cmbHourFrom.Focus();
                return;
			}
			else if (to.Date < from.Date)
			{
                this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg4") + ";", true);
                dtpTo.Focus();
				return;
			}
			else if (from.Date == to.Date && timeTo < timeFrom)
			{
                this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg5") + ";", true);
                cmbHourTo.Focus();
				return;
			}

			BesucherVerwaltungClient.BesuchData besuchData = null;
			if (formMode == BesuchFormMode.Create || formMode == BesuchFormMode.Copy)
			{
				besuchData = new BesucherVerwaltungClient.BesuchData();
				besuchData.MitarbeiterID = Convert.ToInt32(cmbNachname.Items[cmbNachname.SelectedIndex].Value); //(int)Session["MitarbeiterID"];
				besuchData.EingangID = Database.DataAccess.GetFirstEingang(Convert.ToInt32(cmbStandort.Value));
			}
			else
			{
				besuchData = (BesucherVerwaltungClient.BesuchData)Session["BesuchData"];
			}

			DateTime geplanntBeginn = dtpFrom.SelectedDate;
			DateTime geplanntEnde = dtpTo.SelectedDate;
			besuchData.GeplanntBeginn = new DateTime(geplanntBeginn.Year, geplanntBeginn.Month, geplanntBeginn.Day, Convert.ToInt32(cmbHourFrom.Value), Convert.ToInt32(cmbMinuteFrom.Value), 0);
			besuchData.GeplanntEnde = new DateTime(geplanntEnde.Year, geplanntEnde.Month, geplanntEnde.Day, Convert.ToInt32(cmbHourTo.Value), Convert.ToInt32(cmbMinuteTo.Value), 0);
			besuchData.GruppeDatum = DateTime.Now;

            
            if (BesucherTabControl1.TabPages.Count > 1)
            {
                for (int i = 1; i<BesucherTabControl1.TabPages.Count;i++)
                {
                    for (int j = 0; j<i;j++)
                    {
                        if (BesucherTabControl1.TabPages[i].Nachname == BesucherTabControl1.TabPages[j].Nachname && (BesucherTabControl1.TabPages[i].Vorname == BesucherTabControl1.TabPages[j].Vorname || BesucherTabControl1.TabPages[i].Vorname + BesucherTabControl1.TabPages[j].Vorname == String.Empty) && ( BesucherTabControl1.TabPages[i].Firma == BesucherTabControl1.TabPages[j].Firma || BesucherTabControl1.TabPages[i].Firma + BesucherTabControl1.TabPages[j].Firma == String.Empty))
                        {
                            this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg6"), true);
                            return;
                        }
                    }
                }
            }


			for (int i = 0; i < BesucherTabControl1.TabPages.Count; i++)
			{
				BesucherVerwaltung.Controls.BesucherTabPage tabPage = BesucherTabControl1.TabPages[i];

                if (tabPage.Text == (string)GetGlobalResourceObject("Language", "title56"))
				{
					if (String.IsNullOrEmpty(tabPage.Nachname))
					{
						continue;
					}
				}

				if (String.IsNullOrEmpty(tabPage.Nachname))
				{
                    this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg1"), true);
					return;
				}

				BesucherVerwaltungClient.Besucher besucher = formMode == BesuchFormMode.Create || i >= besuchData.BesucherList.Count ? new BesucherVerwaltungClient.Besucher() : besuchData.BesucherList[i];
				besucher.BesucherID = tabPage.BesucherID;
				besucher.Anrede = tabPage.Anrede;
				besucher.AusweisNummer = tabPage.AusweisNr;
				besucher.Firma = tabPage.Firma;
				besucher.Nachname = tabPage.Nachname;
				besucher.SicherheitsHinweis = tabPage.Sicher;
				besucher.Telefon = tabPage.Telefon;
				besucher.Titel = tabPage.Titel;
				besucher.Vip = tabPage.VIP;
				besucher.Vorname = tabPage.Vorname;

				BesucherVerwaltungClient.BesuchPerson besuchPerson = formMode == BesuchFormMode.Create || i >= besuchData.BesucherList.Count ? new BesucherVerwaltungClient.BesuchPerson() : besuchData.BesuchPersonList[i];
				besuchPerson.AbholerOrt = tabPage.Ort;
				besuchPerson.AutoNummer = tabPage.Autonummer;
				besuchPerson.Bemerkung = tabPage.Bemerkungen;
				besuchPerson.ParkPlatz = tabPage.Parkplatz;
				besuchPerson.BesuchsStatus = 1;

				if (formMode == BesuchFormMode.Create || i >= besuchData.BesucherList.Count)
				{
					besuchData.BesucherList.Add(besucher);
					besuchData.BesuchPersonList.Add(besuchPerson);
				}
			}

			if (besuchData.BesucherList.Count == 0)
			{
                this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg1"), true);
				return;
			}
			else if (besuchData.BesucherList.Count > 1)
			{
				if (String.IsNullOrEmpty(txtGroup.Value.Trim()))
				{
                    this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg7") + ";", true);
					txtGroup.Focus();
					return;
				}
				else
				{
                    besuchData.GruppeName = txtGroup.Value.Trim();
				}
			}

			Session["BesuchData"] = besuchData;
			besuchData.ToDatabase();

            this.ClientScript.RegisterStartupScript(typeof(NewBesuchForm), (string)GetGlobalResourceObject("Language", "title57"), (string)GetGlobalResourceObject("Language", "msg9"), true);
			Session["BesuchFormMode"] = BesuchFormMode.Create;

			this.InitForm();
		}
	}

	private void BindBesuchter(Mitarbeiter besuchter)
	{
        //cmbStandort.Value = besuchter.StandortID.ToString();
        cmbStandort.Items.Add(besuchter.StandortID.ToString());

        lblStandort.Text = cmbStandort.Items[cmbStandort.SelectedIndex].Text;

		txtAnrede.Value = besuchter.Anrede;
		txtTitel.Value = besuchter.Titel;
		txtPersNr.Value = besuchter.PersNr;
		txtTelefon.Value = besuchter.Telefon;
		txtAbt.Value = besuchter.Abteilung + " " + besuchter.Dienstelle;
	}

	private void BindFruhereBesucher(int mitarbeiterID)
	{
        //besan2DataSet.GetFruhereBesucherDataTable fbTable = Database.DataAccess.GetFruhereBesucher(mitarbeiterID);

        //cmbFruhereBesucher.Items.Clear();
        //cmbFruhereBesucher.Items.Add(new ListItem(String.Empty, "0"));
        //foreach (DataRow row in fbTable)
        //{
        //    cmbFruhereBesucher.Items.Add(new ListItem((string)row["Name"], row["BesucherID"].ToString()));
        //}
	}

	private void ChangeFormMode(BesuchFormMode formMode)
	{
		bool isReadOnly = formMode == BesuchFormMode.View;

		dtpFrom.ReadOnly = isReadOnly;
		dtpTo.ReadOnly = isReadOnly;
		cmbHourFrom.Disabled = isReadOnly;
		cmbHourTo.Disabled = isReadOnly;
		cmbMinuteFrom.Disabled = isReadOnly;
		cmbMinuteTo.Disabled = isReadOnly;
		cmbNachname.Enabled = !isReadOnly;
		cmbStandort.Disabled = isReadOnly;
        //cmbFruhereBesucher.Enabled = !isReadOnly;

		if (isReadOnly)
		{
			txtGroup.Attributes["readonly"] = "readonly";
		}
		else
		{
			txtGroup.Attributes.Remove("readonly");
		}
		BesucherTabControl1.ReadOnly = isReadOnly;
		//btnOkay.Visible = isReadOnly;
	}

    private void InitForm()
    {
        BesucherTabControl1.TabPages.Clear();
        BesucherVerwaltung.Controls.BesucherTabPage tabPage = BesucherTabControl1.AddTabPage("Neu");
        tabPage.DeleteEnabled = false;

        BesucherVerwaltungClient.BesuchData data = new BesucherVerwaltungClient.BesuchData();
        Session["BesuchData"] = data;

        txtGroup.Value = String.Empty;
        lblGroupSize.Text = "0";

        btnOkay.Text = (string)GetGlobalResourceObject("Language","But4");

        DateTime now = DateTime.Now;

        cmbHourFrom.SelectedIndex = now.TimeOfDay.Hours + 1;
		cmbMinuteFrom.SelectedIndex = 0;
        cmbHourTo.SelectedIndex = now.TimeOfDay.Hours + 3;
		cmbMinuteTo.SelectedIndex = 0;

		leftNavLink1.Attributes["class"] = "navLink2Selected";
		leftNavLink2.Attributes["class"] = "navLink2";
	}
}