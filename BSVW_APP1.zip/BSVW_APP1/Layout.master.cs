using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;

public partial class Layout : System.Web.UI.MasterPage
{
   
	protected void Page_Load(object sender, EventArgs e)
	{
        Page.Title = (string)GetGlobalResourceObject("Language", "title1");       

	}
    protected void SelectEnglish(object sender, EventArgs e)
    {
        HttpCookie cookie = Request.Cookies["besanlanguage"];
        
        if (cookie == null)
        {
            cookie = new HttpCookie("besanlanguage");
        }
        cookie["balang"] = "en-US";
        cookie.Expires = DateTime.Now.AddDays(7);
        Response.Cookies.Add(cookie);
        Response.Redirect(this.Request.Url.AbsolutePath);
    }
    protected void SelectDeutsch(object sender, EventArgs e)
    {
        HttpCookie cookie = Request.Cookies["besanlanguage"];

        if (cookie == null)
        {
            cookie = new HttpCookie("besanlanguage");
        }
        cookie["balang"] = "de-AT";
        cookie.Expires = DateTime.Now.AddDays(7);
        Response.Cookies.Add(cookie);
        Response.Redirect(this.Request.Url.AbsolutePath);
    }
    //protected void InitializeCulture(string lang)
    //{
    //    CultureInfo info = new CultureInfo(lang);
    //    System.Threading.Thread.CurrentThread.CurrentCulture = info;
    //    System.Threading.Thread.CurrentThread.CurrentUICulture = info;      
    //}
}
