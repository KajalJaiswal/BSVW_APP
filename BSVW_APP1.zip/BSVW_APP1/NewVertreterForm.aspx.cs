using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;

public partial class NewVertreterForm : BesanPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
        lblFooterDatum.Text = Global.GetDatum();

		if (!this.IsPostBack)
		{
			if (Session["MitarbeiterID"] != null)
			{
				Mitarbeiter m = Mitarbeiter.Get((int)Session["MitarbeiterID"]);
				cmbNachname.Items.Add(new ListItem(m.Nachname, m.MitarbeiterID.ToString()));
				txtVorname.Value = m.Vorname;
				txtPersNr.Value = m.PersNr;
				txtFKz.Value = m.Fkz.ToString("0#");
			}
			else
			{
				Response.Redirect("LoginForm.aspx");
			}
		}
	}

	protected void btnSearch_ServerClick(object sender, EventArgs e)
	{
		DataAccess da = Database.DataAccess;
		vertreterTable.Visible = true;
		vertreterTable.TableClass = "listTable";
		vertreterTable.ValueMember = "MitarbeiterID";
		vertreterTable.DataSource = da.FindMitarbeiterFromNachname(txtSearch.Value.Replace("*", "%"));
	}

	protected void vertreterTable_SelectedRowChanged(object sender, BesucherVerwaltung.Controls.RowChangedEventArgs e)
	{
		DataAccess da = Database.DataAccess;
		da.InsertVertreter((int)Session["MitarbeiterID"], (int)vertreterTable.SelectedValue);

		vertreterTable.Visible = false;
		vertreterTable.DataSource = null;

        this.ClientScript.RegisterStartupScript(typeof(NewVertreterForm), (string)GetGlobalResourceObject("Language", "error"), (string)GetGlobalResourceObject("Language", "msg10"), true);
		//Response.Redirect("NewVertreterForm.aspx");
	}
}